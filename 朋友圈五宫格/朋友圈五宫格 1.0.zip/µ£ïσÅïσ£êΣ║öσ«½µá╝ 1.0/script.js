class FriendCircleAnalyzer {
    constructor() {
        this.uploadedImages = [];
        this.maxImages = 20;
        this.minImages = 5;
        this.maxFileSize = 10 * 1024 * 1024; // 10MB
        
        this.initializeElements();
        this.bindEvents();
    }
    
    initializeElements() {
        // 获取页面元素
        this.uploadArea = document.getElementById('uploadArea');
        this.fileInput = document.getElementById('fileInput');
        this.uploadBtn = document.getElementById('uploadBtn');
        this.previewArea = document.getElementById('previewArea');
        this.imageGrid = document.getElementById('imageGrid');
        this.imageCount = document.getElementById('imageCount');
        this.addMoreBtn = document.getElementById('addMoreBtn');
        this.analyzeBtn = document.getElementById('analyzeBtn');
        
        this.uploadSection = document.getElementById('uploadSection');
        this.analysisSection = document.getElementById('analysisSection');
        this.resultSection = document.getElementById('resultSection');
        
        this.progressFill = document.getElementById('progressFill');
        this.progressText = document.getElementById('progressText');
        
        this.resetBtn = document.getElementById('resetBtn');
        this.shareBtn = document.getElementById('shareBtn');
        this.downloadReportBtn = document.getElementById('downloadReportBtn');
        
        this.loadingOverlay = document.getElementById('loadingOverlay');
        
        // 存储分析结果用于下载报告
        this.currentAnalysisResult = null;
    }
    
    bindEvents() {
        // 上传按钮点击事件
        this.uploadBtn.addEventListener('click', () => {
            this.fileInput.click();
        });
        
        // 文件选择事件
        this.fileInput.addEventListener('change', (e) => {
            this.handleFileSelect(e.target.files);
        });
        
        // 拖拽上传事件
        this.uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            this.uploadArea.classList.add('dragover');
        });
        
        this.uploadArea.addEventListener('dragleave', (e) => {
            e.preventDefault();
            this.uploadArea.classList.remove('dragover');
        });
        
        this.uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            this.uploadArea.classList.remove('dragover');
            this.handleFileSelect(e.dataTransfer.files);
        });
        
        // 继续添加按钮
        this.addMoreBtn.addEventListener('click', () => {
            this.fileInput.click();
        });
        
        // 开始分析按钮
        this.analyzeBtn.addEventListener('click', () => {
            this.startAnalysis();
        });
        
        // 重新分析按钮
        this.resetBtn.addEventListener('click', () => {
            this.resetAnalysis();
        });
        
        // 分享按钮
        this.shareBtn.addEventListener('click', () => {
            this.shareResults();
        });
        
        // 下载详细报告按钮
        this.downloadReportBtn.addEventListener('click', () => {
            this.downloadDetailedReport();
        });
    }
    
    handleFileSelect(files) {
        const newFiles = Array.from(files).filter(file => {
            // 检查文件类型
            if (!file.type.startsWith('image/')) {
                this.showNotification('请选择图片文件！', 'error');
                return false;
            }
            
            // 检查文件大小
            if (file.size > this.maxFileSize) {
                this.showNotification('图片大小不能超过10MB！', 'error');
                return false;
            }
            
            // 检查总数量
            if (this.uploadedImages.length >= this.maxImages) {
                this.showNotification(`最多只能上传${this.maxImages}张图片！`, 'error');
                return false;
            }
            
            return true;
        });
        
        if (newFiles.length === 0) return;
        
        // 处理新文件
        newFiles.forEach(file => {
            if (this.uploadedImages.length < this.maxImages) {
                this.processImage(file);
            }
        });
    }
    
    processImage(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const imageData = {
                file: file,
                url: e.target.result,
                id: Date.now() + Math.random()
            };
            
            this.uploadedImages.push(imageData);
            this.updateImagePreview();
            this.updateAnalyzeButton();
        };
        reader.readAsDataURL(file);
    }
    
    updateImagePreview() {
        // 显示预览区域
        if (this.uploadedImages.length > 0) {
            this.previewArea.style.display = 'block';
        }
        
        // 更新图片数量
        this.imageCount.textContent = this.uploadedImages.length;
        
        // 清空并重新渲染图片网格
        this.imageGrid.innerHTML = '';
        
        this.uploadedImages.forEach((imageData, index) => {
            const imageItem = document.createElement('div');
            imageItem.className = 'image-item';
            
            imageItem.innerHTML = `
                <img src="${imageData.url}" alt="朋友圈截图 ${index + 1}">
                <button class="remove-btn" onclick="analyzer.removeImage(${index})">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            this.imageGrid.appendChild(imageItem);
        });
    }
    
    removeImage(index) {
        this.uploadedImages.splice(index, 1);
        this.updateImagePreview();
        this.updateAnalyzeButton();
        
        // 如果没有图片了，隐藏预览区域
        if (this.uploadedImages.length === 0) {
            this.previewArea.style.display = 'none';
        }
    }
    
    updateAnalyzeButton() {
        this.analyzeBtn.disabled = this.uploadedImages.length < this.minImages;
        
        if (this.uploadedImages.length < this.minImages) {
            this.analyzeBtn.textContent = `开始分析（还需${this.minImages - this.uploadedImages.length}张）`;
        } else {
            this.analyzeBtn.textContent = '开始分析';
        }
    }
    
    async startAnalysis() {
        try {
            // 显示分析界面
            this.showAnalysisSection();
            
            // 模拟进度更新
            this.updateProgress(0, '准备图片处理...');
            
            // 准备图片数据
            const imageDataList = await this.prepareImageData();
            this.updateProgress(30, '正在调用AI分析...');
            
            // 调用后端API
            const analysisResult = await this.callAnalysisAPI(imageDataList);
            this.updateProgress(90, '生成分析报告...');
            
            // 显示结果
            await this.sleep(500);
            this.showResults(analysisResult);
            
        } catch (error) {
            console.error('分析失败:', error);
            this.showNotification('分析失败，请重试！', 'error');
            this.resetToUpload();
        }
    }
    
    async prepareImageData() {
        const imageDataList = [];
        
        for (let i = 0; i < this.uploadedImages.length; i++) {
            const imageData = this.uploadedImages[i];
            
            // 压缩图片
            const compressedDataUrl = await this.compressImage(imageData.file);
            
            imageDataList.push({
                id: imageData.id,
                dataUrl: compressedDataUrl,
                name: imageData.file.name,
                size: imageData.file.size
            });
            
            // 更新进度
            const progress = Math.floor((i + 1) / this.uploadedImages.length * 25);
            this.updateProgress(progress, `处理图片 ${i + 1}/${this.uploadedImages.length}...`);
        }
        
        return imageDataList;
    }
    
    async compressImage(file, maxWidth = 800, quality = 0.8) {
        return new Promise((resolve) => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const img = new Image();
            
            img.onload = () => {
                // 计算压缩后的尺寸
                let { width, height } = img;
                if (width > maxWidth) {
                    height = (height * maxWidth) / width;
                    width = maxWidth;
                }
                
                canvas.width = width;
                canvas.height = height;
                
                // 绘制并压缩
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            
            img.src = URL.createObjectURL(file);
        });
    }
    
    async callAnalysisAPI(imageDataList) {
        const response = await fetch('/api/analyze', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                images: imageDataList
            })
        });
        
        if (!response.ok) {
            throw new Error(`分析请求失败: ${response.status}`);
        }
        
        return await response.json();
    }
    
    showAnalysisSection() {
        this.uploadSection.style.display = 'none';
        this.analysisSection.style.display = 'block';
        this.resultSection.style.display = 'none';
    }
    
    showResults(result) {
        this.uploadSection.style.display = 'none';
        this.analysisSection.style.display = 'none';
        this.resultSection.style.display = 'block';
        
        // 保存分析结果用于下载报告
        this.currentAnalysisResult = result;
        
        // 渲染分析结果
        const data = result.data || result; // 处理API响应格式
        this.renderPersonalityTags(data.personality?.tags || []);
        this.renderPersonalityDescription(data.personality?.description || '');
        this.renderInterestTags(data.interests || []);
        this.renderSuggestions(data.suggestions || []);
        this.renderChatTopics(data.chatTopics || []);
        this.renderDateSuggestions(data.dateSuggestions || []);
    }
    
    renderPersonalityTags(tags) {
        const container = document.getElementById('personalityTags');
        container.innerHTML = '';
        
        tags.forEach(tag => {
            const tagElement = document.createElement('span');
            tagElement.className = 'tag';
            tagElement.textContent = tag;
            container.appendChild(tagElement);
        });
    }
    
    renderPersonalityDescription(description) {
        const container = document.getElementById('personalityDesc');
        container.textContent = description;
    }
    
    renderInterestTags(interests) {
        const container = document.getElementById('interestTags');
        container.innerHTML = '';
        
        interests.forEach(interest => {
            const tagElement = document.createElement('span');
            tagElement.className = 'tag';
            tagElement.textContent = interest;
            container.appendChild(tagElement);
        });
    }
    
    renderSuggestions(suggestions) {
        const container = document.getElementById('suggestions');
        container.innerHTML = '';
        
        suggestions.forEach(suggestion => {
            const item = document.createElement('div');
            item.className = 'suggestion-item';
            item.textContent = suggestion;
            container.appendChild(item);
        });
    }
    
    renderChatTopics(topics) {
        const container = document.getElementById('chatTopics');
        container.innerHTML = '';
        
        topics.forEach(topic => {
            const item = document.createElement('div');
            item.className = 'topic-item';
            item.textContent = topic;
            container.appendChild(item);
        });
    }
    
    renderDateSuggestions(suggestions) {
        const container = document.getElementById('dateSuggestions');
        container.innerHTML = '';
        
        suggestions.forEach(suggestion => {
            const item = document.createElement('div');
            item.className = 'date-item';
            item.textContent = suggestion;
            container.appendChild(item);
        });
    }
    
    updateProgress(percentage, text) {
        this.progressFill.style.width = `${percentage}%`;
        this.progressText.textContent = text;
    }
    
    resetAnalysis() {
        this.uploadedImages = [];
        this.uploadSection.style.display = 'block';
        this.analysisSection.style.display = 'none';
        this.resultSection.style.display = 'none';
        this.previewArea.style.display = 'none';
        this.imageGrid.innerHTML = '';
        this.imageCount.textContent = '0';
        this.updateAnalyzeButton();
        this.fileInput.value = '';
    }
    
    resetToUpload() {
        this.uploadSection.style.display = 'block';
        this.analysisSection.style.display = 'none';
        this.resultSection.style.display = 'none';
    }
    
    shareResults() {
        // 简单的分享功能
        if (navigator.share) {
            navigator.share({
                title: '朋友圈五宫格 - 分析结果',
                text: '我刚用AI分析了朋友圈，结果超准的！',
                url: window.location.href
            });
        } else {
            // 备用分享方式
            const url = window.location.href;
            navigator.clipboard.writeText(url).then(() => {
                this.showNotification('链接已复制到剪贴板！', 'success');
            });
        }
    }
    
    async downloadDetailedReport() {
        if (!this.currentAnalysisResult) {
            this.showNotification('请先完成分析再下载报告！', 'error');
            return;
        }
        
        try {
            this.showNotification('正在生成详细报告...', 'info');
            
            // 准备要重新分析的图片数据
            const imagesToAnalyze = this.uploadedImages.map(imageData => ({
                dataUrl: imageData.dataUrl
            }));
            
            // 调用详细分析API
            const response = await fetch('/api/detailed-analyze', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    images: imagesToAnalyze
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            
            if (result.success && result.htmlReport) {
                // 创建Blob并下载HTML文件
                const blob = new Blob([result.htmlReport], { type: 'text/html' });
                const url = window.URL.createObjectURL(blob);
                
                const a = document.createElement('a');
                a.href = url;
                a.download = `朋友圈深度分析报告_${new Date().toLocaleDateString('zh-CN').replace(/\//g, '-')}.html`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                
                window.URL.revokeObjectURL(url);
                
                this.showNotification('详细报告下载成功！', 'success');
            } else {
                throw new Error(result.error || '生成报告失败');
            }
            
        } catch (error) {
            console.error('下载详细报告失败:', error);
            this.showNotification(`下载失败: ${error.message}`, 'error');
        }
    }
    
    showNotification(message, type = 'info') {
        // 创建通知元素
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <i class="fas ${type === 'error' ? 'fa-exclamation-circle' : type === 'success' ? 'fa-check-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        `;
        
        // 添加样式
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'error' ? '#ff4757' : type === 'success' ? '#2ed573' : '#3742fa'};
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            z-index: 10000;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 500;
            transform: translateX(100%);
            transition: transform 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        // 显示动画
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // 自动消失
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// 初始化应用
const analyzer = new FriendCircleAnalyzer();

// 导出到全局作用域，供HTML中的onclick使用
window.analyzer = analyzer; 