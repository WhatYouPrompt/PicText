const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;

// 中间件配置
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static('.'));

// 豆包大模型配置
const DOUBAO_CONFIG = {
    baseURL: 'https://ark.cn-beijing.volces.com/api/v3',
    apiKey: process.env.DOUBAO_API_KEY || '8ceb1e51-6022-479f-97c4-f78a791ddbd6', // 使用提供的API密钥
    model: 'doubao-seed-1-6-thinking-250615' // 使用正确的模型名称
};

// System Prompt
const SYSTEM_PROMPT = `你是一个追求异性的高手，对于青春男女生的心理和外在表现，有非常强的洞察，也有一套很厉害的追求异性的技巧！擅长于输出简短但有效的分析和建议。

请分析用户上传的朋友圈截图，从以下维度进行分析：
1. 性格特征（外向/内向、感性/理性等）
2. 兴趣爱好（运动、艺术、美食、旅行等）
3. 生活状态（工作、经济水平、社交圈等）
4. 沟通风格（幽默、严肃、文艺等）

并提供针对性的追求建议：
- 聊天话题推荐
- 约会场所建议
- 沟通方式指导
- 表白时机建议

请保持分析和建议简洁明了，每个要点不超过20字。

返回格式要求是JSON：
{
    "personality": {
        "tags": ["外向", "感性", "乐观"],
        "description": "性格开朗活泼，喜欢分享生活，对新鲜事物充满好奇心"
    },
    "interests": ["美食", "旅行", "摄影", "音乐"],
    "suggestions": ["展示你的幽默感", "主动分享有趣经历", "约她一起体验新事物"],
    "chatTopics": ["推荐好吃的餐厅", "分享旅行见闻", "讨论音乐品味"],
    "dateSuggestions": ["网红餐厅用餐", "艺术展览参观", "音乐节现场"]
}`;

// 详细分析 System Prompt
const DETAILED_SYSTEM_PROMPT = `你是一个追求异性的高手，对于青春男女生的心理和外在表现，有非常强的洞察，也有一套很厉害的追求异性的技巧！

请详细分析这些朋友圈截图，提供深度洞察和具体建议：

1. 深度性格分析 - 分析其内在性格特质、价值观、生活态度、情绪特点
2. 兴趣爱好详解 - 识别其真正的兴趣点、生活重心、消费习惯
3. 社交模式分析 - 分析其社交习惯、朋友圈定位、人际关系特点
4. 恋爱心理分析 - 分析其情感状态、择偶偏好、恋爱经验
5. 具体追求策略 - 提供分阶段的追求方案和实操建议
6. 沟通技巧指导 - 详细的聊天话题和沟通方式
7. 约会规划建议 - 具体的约会场所、时间、活动安排
8. 风险提示 - 指出需要注意的问题点和禁忌

请详细分析并返回结构化JSON数据：
{
    "deepPersonality": {
        "coreTraits": ["核心性格特质"],
        "values": ["价值观倾向"],
        "lifestyle": "生活态度描述",
        "emotionalPattern": "情绪模式分析"
    },
    "detailedInterests": {
        "primaryInterests": ["主要兴趣"],
        "lifestyle": ["生活方式"],
        "consumption": ["消费习惯"],
        "socialActivities": ["社交活动"]
    },
    "socialPattern": {
        "networkStyle": "社交网络特点",
        "postingHabits": "发布习惯",
        "interactionStyle": "互动方式",
        "relationships": "人际关系状态"
    },
    "loveAnalysis": {
        "currentStatus": "当前情感状态",
        "preferences": ["择偶偏好"],
        "experience": "恋爱经验推测",
        "readiness": "恋爱准备度"
    },
    "pursuitStrategy": {
        "phases": [
            {
                "phase": "初始接触",
                "duration": "时间周期",
                "actions": ["具体行动"],
                "goals": ["阶段目标"]
            }
        ],
        "overallApproach": "整体策略"
    },
    "communicationGuide": {
        "chatTopics": [
            {
                "topic": "话题类别",
                "examples": ["具体例子"],
                "tips": ["沟通技巧"]
            }
        ],
        "conversationStyle": "推荐沟通风格",
        "taboos": ["聊天禁忌"]
    },
    "dateRecommendations": [
        {
            "type": "约会类型",
            "location": "具体地点建议",
            "timing": "最佳时机",
            "preparation": ["准备事项"],
            "reasons": "推荐理由"
        }
    ],
    "riskWarnings": [
        {
            "risk": "风险点",
            "description": "详细说明",
            "avoidance": "规避方法"
        }
    ]
}`;

// 将base64图片转换为豆包API可以使用的格式
function prepareImageForAPI(imageDataUrl) {
    // 豆包API支持直接使用data URL
    return imageDataUrl;
}

// 调用豆包大模型（支持图片分析）
async function callDoubaoAPI(images, textPrompt, isDetailed = false) {
    try {
        // 构建包含图片的消息内容
        const messageContent = [
            {
                type: "text",
                text: textPrompt
            }
        ];

        // 添加图片到消息内容中
        images.forEach((imageDataUrl, index) => {
            messageContent.push({
                type: "image_url",
                image_url: {
                    url: imageDataUrl
                }
            });
        });

        const response = await axios.post(
            `${DOUBAO_CONFIG.baseURL}/chat/completions`,
            {
                model: DOUBAO_CONFIG.model,
                messages: [
                    {
                        role: "system",
                        content: isDetailed ? DETAILED_SYSTEM_PROMPT : SYSTEM_PROMPT
                    },
                    {
                        role: "user",
                        content: messageContent
                    }
                ],
                temperature: 0.7,
                max_tokens: 2000
            },
            {
                headers: {
                    'Authorization': `Bearer ${DOUBAO_CONFIG.apiKey}`,
                    'Content-Type': 'application/json'
                },
                timeout: 60000 // 增加超时时间，因为需要处理图片
            }
        );

        const content = response.data.choices[0].message.content;
        console.log('AI分析结果:', content);
        
        // 尝试解析JSON响应
        try {
            return JSON.parse(content);
        } catch (parseError) {
            console.log('AI返回的不是标准JSON，尝试提取信息:', content);
            return parseAIResponse(content);
        }
        
    } catch (error) {
        console.error('调用豆包API失败:', error.message);
        if (error.response) {
            console.error('API响应错误:', error.response.status, error.response.data);
        }
        
        // 返回模拟数据作为备用
        return getMockAnalysisResult();
    }
}

// 解析非JSON格式的AI响应
function parseAIResponse(content) {
    // 简单的文本解析逻辑
    const result = {
        personality: {
            tags: ["开朗", "社交", "积极"],
            description: "从朋友圈内容可以看出是个积极向上的人"
        },
        interests: ["美食", "社交", "生活"],
        suggestions: ["主动聊天", "展示关心", "分享有趣话题"],
        chatTopics: ["美食推荐", "生活趣事", "共同兴趣"],
        dateSuggestions: ["餐厅约会", "轻松聚会", "兴趣活动"]
    };
    
    return result;
}

// 模拟分析结果（用于测试和备用）
function getMockAnalysisResult() {
    const mockResults = [
        {
            personality: {
                tags: ["外向", "乐观", "感性"],
                description: "性格开朗活泼，热爱生活，经常分享美好时光，社交能力强"
            },
            interests: ["美食", "旅行", "摄影", "健身"],
            suggestions: [
                "主动邀请一起品尝美食",
                "分享旅行攻略和经历", 
                "夸赞她的摄影技术",
                "约一起运动健身"
            ],
            chatTopics: [
                "推荐好吃的餐厅",
                "讨论旅行目的地",
                "分享摄影技巧",
                "交流健身心得"
            ],
            dateSuggestions: [
                "网红餐厅探店",
                "周末户外徒步",
                "摄影主题约会",
                "健身房一起锻炼"
            ]
        },
        {
            personality: {
                tags: ["文艺", "内敛", "细腻"],
                description: "内心世界丰富，喜欢思考和感受，对艺术有独特见解"
            },
            interests: ["读书", "电影", "音乐", "艺术"],
            suggestions: [
                "推荐优质书籍和电影",
                "分享音乐品味",
                "讨论艺术话题",
                "展示你的文化底蕴"
            ],
            chatTopics: [
                "最近在读的好书",
                "经典电影推荐",
                "音乐风格偏好",
                "艺术展览观后感"
            ],
            dateSuggestions: [
                "书店咖啡厅约会",
                "电影院看文艺片",
                "音乐会现场",
                "美术馆参观"
            ]
        }
    ];
    
    return mockResults[Math.floor(Math.random() * mockResults.length)];
}

// 详细分析模拟结果 - 追求高手版
function getDetailedMockAnalysisResult() {
    return {
        targetProfile: {
            name: "目标对象画像",
            ageRange: "23-28岁",
            lifeStage: "职场新人/上升期",
            economicLevel: "中等收入，有一定消费能力",
            socialStatus: "朋友圈活跃，社交广泛"
        },
        deepPersonality: {
            coreTraits: ["外向开朗", "感性细腻", "积极乐观", "追求品质", "有主见", "情商较高"],
            values: ["注重生活品质", "珍视友情", "热爱自由", "追求真实", "相信爱情", "重视成长"],
            lifestyle: "热爱生活，注重体验，喜欢分享美好时光，有一定的生活品味和追求。生活节奏适中，既有工作目标也懂得享受当下。",
            emotionalPattern: "情绪表达较为直接，容易被美好事物感动，具有较强的共情能力。在恋爱中倾向于感性决策，但也会理性思考。",
            defenseMechanism: "当感到压力时，会通过社交和娱乐来缓解。对于过于主动的追求者可能会产生防备心理。",
            attractionTriggers: ["真诚的关心", "有趣的灵魂", "生活品味", "情感共鸣", "适度的神秘感"]
        },
        detailedInterests: {
            primaryInterests: ["美食探索", "旅行摄影", "社交聚会", "时尚生活", "文艺活动", "健身运动"],
            lifestyle: ["精致生活", "社交活跃", "注重仪式感", "热爱分享", "追求新鲜感"],
            consumption: ["品质导向", "体验优先", "社交需求", "颜值经济", "情感消费"],
            socialActivities: ["朋友聚餐", "旅行打卡", "购物分享", "文化活动", "网红店探店", "节日庆祝"],
            hiddenInterests: ["内心渴望被理解", "希望遇到有趣的人", "对未来有憧憬", "偶尔也会孤独"],
            avoidancePattern: ["避免无聊的人", "不喜欢被过度控制", "讨厌虚假的奉承", "拒绝低质量社交"]
        },
        socialPattern: {
            networkStyle: "社交圈较为活跃，朋友众多，喜欢分享生活点滴。在社交中扮演活跃分子角色，善于营造氛围。",
            postingHabits: "频率适中（每周2-3次），内容丰富，多为正面积极的生活分享。偏爱发布美食、旅行、聚会等高质量内容。",
            interactionStyle: "互动性强，回复积极，善于维护社交关系。点赞评论都比较及时，重视社交礼仪。",
            relationships: "人缘较好，朋友关系融洽，可能处于单身或恋爱初期。朋友圈中以女性朋友居多，也有一些异性朋友。",
            digitalBehavior: "社交媒体使用频繁，注重形象管理，会精心选择发布内容。回复速度较快，说明经常在线。",
            socialSignals: ["发布内容精心策划", "互动积极但有选择性", "注重社交形象", "群体归属感强"]
        },
        loveAnalysis: {
            currentStatus: "情感状态相对稳定，对爱情持开放态度。可能刚结束一段关系或正在寻找合适的人。",
            preferences: ["有趣的灵魂", "生活品味相近", "能够陪伴成长", "懂得浪漫", "有上进心", "尊重女性"],
            experience: "有一定恋爱经验，对感情比较理性，但仍保持浪漫期待。不会轻易开始一段关系，但一旦认真起来会很投入。",
            readiness: "具备恋爱的心理准备，期待遇到合适的人。对感情质量要求较高，不会为了恋爱而恋爱。",
            emotionalNeeds: ["被理解和认同", "精神层面的交流", "生活情趣的分享", "未来规划的支持"],
            redFlags: ["过于黏腻", "缺乏个人空间", "价值观不合", "生活品味差距过大", "不尊重朋友"],
            attractionSequence: ["外表吸引", "谈吐加分", "共同话题", "价值观认同", "情感共鸣", "长期兼容"]
        },
        pursuitStrategy: {
            phases: [
                {
                    phase: "预热阶段",
                    duration: "1-2周",
                    actions: [
                        "观察朋友圈动态，了解生活规律和兴趣点",
                        "适度点赞（不要每条都点，选择有质量的内容）",
                        "偶尔评论，展示幽默感和见识",
                        "通过共同朋友了解更多信息",
                        "在自己朋友圈展示高价值生活"
                    ],
                    goals: ["建立初步印象", "引起轻微注意", "建立正面形象"],
                    timing: "最佳互动时间：晚上8-10点，周末下午",
                    mindset: "保持神秘感，不要显得太急切",
                    避免错误: ["频繁点赞", "过度评论", "发送无意义信息", "展示需求感"]
                },
                {
                    phase: "建立联系",
                    duration: "2-3周", 
                    actions: [
                        "找合适理由开始私信（如：朋友圈美食推荐）",
                        "分享有趣的生活片段，展示个人魅力",
                        "主动关心但不过度（如：天气变化、工作忙碌）",
                        "邀请参加群体活动，降低压力感",
                        "逐步增加聊天频率和深度"
                    ],
                    goals: ["建立日常联系", "增进相互了解", "创造线下见面机会"],
                    timing: "回复时间：1-3小时（显示生活充实但重视对方）",
                    mindset: "展示真实的自己，但要突出优点",
                    避免错误: ["秒回信息", "话题单一", "过分讨好", "透露全部信息"]
                },
                {
                    phase: "情感升温",
                    duration: "3-4周",
                    actions: [
                        "安排精心策划的一对一约会",
                        "在约会中展示细心和体贴",
                        "分享更深层的想法和感受",
                        "创造身体接触机会（如：扶手、拥抱）",
                        "表达对她的特别感觉，但不要太直接"
                    ],
                    goals: ["建立情感连接", "确认相互好感", "为告白做准备"],
                    timing: "约会时间：周末下午+晚上，营造完整体验",
                    mindset: "真诚表达情感，同时保持男性魅力",
                    避免错误: ["过早表白", "过分亲密", "忽略她的感受", "表现得太完美"]
                },
                {
                    phase: "确定关系",
                    duration: "1-2周",
                    actions: [
                        "选择合适时机和场景进行告白",
                        "表达认真交往的想法",
                        "讨论彼此对感情的期望",
                        "正式确定男女朋友关系",
                        "向朋友圈官宣（如果她愿意）"
                    ],
                    goals: ["正式确定关系", "开始恋爱生活"],
                    timing: "告白最佳时机：两人独处、氛围浪漫、她心情很好",
                    mindset: "自信但不强势，给她思考空间",
                    避免错误: ["强迫回应", "设定时限", "威胁离开", "过分承诺"]
                }
            ],
            overallApproach: "采用'拉拉推推'策略，在展示高价值的同时保持适度距离感，让她主动投入更多情感",
            corePhilosophy: "真诚是最大的套路，但真诚需要智慧地表达",
            successIndicators: ["她主动发起话题", "回复速度变快", "分享私人信息", "主动约你见面", "在朋友面前提到你"]
        },
        communicationGuide: {
            chatTopics: [
                {
                    topic: "美食探索",
                    examples: ["刚发现一家宝藏小店", "这道菜的做法有点意思", "你吃过最难忘的美食是什么"],
                    tips: ["先分享自己的体验", "询问她的偏好", "自然过渡到约饭"],
                    timing: "饭点前后最有效",
                    进阶技巧: ["记住她的忌口", "推荐符合她品味的餐厅", "分享美食背后的故事"]
                },
                {
                    topic: "旅行见闻",
                    examples: ["这个城市的天气让我想起...", "你的旅行照片构图真棒", "下次想去哪里看看"],
                    tips: ["从她的照片入手", "分享有趣的经历", "暗示一起旅行的可能"],
                    timing: "她刚发旅行动态时",
                    进阶技巧: ["提供实用的旅行建议", "分享小众但美丽的地点", "规划future trip"]
                },
                {
                    topic: "生活感悟",
                    examples: ["最近在思考一个问题", "工作中的小确幸", "今天遇到的有趣事情"],
                    tips: ["展现思考深度", "引发她的共鸣", "避免过于沉重"],
                    timing: "她表达情感时回应",
                    进阶技巧: ["提供新的视角", "用故事而非道理", "适时展现脆弱面"]
                },
                {
                    topic: "兴趣爱好",
                    examples: ["你的摄影技术进步很快", "这本书/电影我也很喜欢", "有什么新的爱好吗"],
                    tips: ["真诚地欣赏", "分享相关经验", "提议一起参与"],
                    timing: "她分享作品或心得时",
                    进阶技巧: ["提供专业建议", "介绍相关资源", "成为她的成长伙伴"]
                }
            ],
            conversationFlow: {
                opening: "以观察和赞美开始，找到共同话题",
                maintenance: "保持50/50的分享比例，倾听比说话更重要",
                deepening: "逐步分享更私人的想法，测试她的接受度",
                closing: "留点悬念，让她期待下次交流"
            },
            messageStructure: {
                frequency: "一天1-3条，保持神秘感",
                length: "长短结合，重要信息可以长一些",
                timing: "避开工作时间，选择她活跃的时段",
                response: "不要秒回，也不要超过半天"
            },
            emotionalCalibration: {
                读懂信号: ["回复速度", "表情包使用", "分享私人信息", "主动延续话题"],
                升级时机: ["她开始询问你的个人信息", "分享她的烦恼", "邀请你参与活动"],
                降温信号: ["回复变短", "不再主动", "很久才回消息", "避免深度话题"]
            },
            conversationStyle: "轻松自然，幽默风趣，适度关心，避免过于直接。保持好奇心和倾听态度，用故事而非道理来分享观点。",
            taboos: ["询问前任", "讨论政治敏感话题", "过度炫耀", "负能量抱怨", "催促回应", "频繁表白"]
        },
        dateRecommendations: [
            {
                type: "初次约会 - 美食探店",
                location: "有特色但不过于昂贵的餐厅",
                timing: "周末下午2-4点，时间可控",
                preparation: ["提前踩点确认环境", "了解菜单和推荐", "准备2-3个话题备用", "确认她的忌口"],
                execution: ["主动点菜但询问意见", "分享美食体验", "观察她的喜好", "买单时要自然"],
                reasons: "低压力环境，有话题支撑，时间灵活，符合她的兴趣",
                success_tips: ["选择适合拍照的环境", "点一些可以分享的食物", "关注用餐礼仪"],
                budget: "200-500元"
            },
            {
                type: "进阶约会 - 文化体验",
                location: "艺术展、博物馆、创意市集",
                timing: "周末全天，营造完整体验",
                preparation: ["提前了解展览内容", "准备相关知识但不卖弄", "规划路线包含休息点"],
                execution: ["做她的专属导游", "适时分享见解", "拍照留念", "配合后续活动"],
                reasons: "展现文化素养，提供丰富话题，创造共同回忆",
                success_tips: ["选择她感兴趣的主题", "准备小礼品（如明信片）", "注意她的疲劳度"],
                budget: "300-800元"
            },
            {
                type: "深度约会 - 生活体验",
                location: "烹饪课程、手工体验、户外活动",
                timing: "周末半天+晚餐",
                preparation: ["选择她未尝试过的活动", "确认她的接受度", "准备应急方案"],
                execution: ["一起学习新技能", "互相鼓励", "创造身体接触机会", "记录美好时刻"],
                reasons: "增强亲密感，创造独特体验，展现生活情趣",
                success_tips: ["选择有成就感的活动", "准备小惊喜", "关注她的情绪变化"],
                budget: "500-1200元"
            },
            {
                type: "表白约会 - 浪漫仪式",
                location: "有纪念意义的地点",
                timing: "夕阳西下或夜景最美时",
                preparation: ["精心策划每个环节", "准备表白词", "选择合适的礼物", "确保私密性"],
                execution: ["营造浪漫氛围", "真诚表达感情", "给她思考时间", "无论结果都要绅士"],
                reasons: "正式表达心意，创造难忘回忆，展现认真态度",
                success_tips: ["不要过于复杂", "准备plan B", "控制情绪", "尊重她的决定"],
                budget: "800-2000元"
            }
        ],
        riskWarnings: [
            {
                risk: "需求感过强",
                description: "表现得太急切，频繁联系，过度讨好，让对方感到压力",
                warning_signs: ["秒回消息", "频繁点赞", "过度关心", "总是迁就"],
                avoidance: "保持自己的生活节奏，展示高价值，让她也投入情感",
                remedy: "适当冷淡，专注自己的事业和爱好，重新吸引注意"
            },
            {
                risk: "话题单一乏味",
                description: "总是聊同样的话题，缺乏新鲜感和深度",
                warning_signs: ["她回复越来越短", "不主动延续话题", "很久才回消息"],
                avoidance: "准备多样化话题，关注她的动态，培养共同兴趣",
                remedy: "主动学习新知识，分享有趣经历，问开放性问题"
            },
            {
                risk: "节奏把控不当",
                description: "推进太快或太慢，没有抓住关键时机",
                warning_signs: ["她开始回避约会", "保持距离", "不愿深入交流"],
                avoidance: "观察她的反应，及时调整策略，尊重她的节奏",
                remedy: "坦诚沟通，询问她的感受，重新建立舒适的交往节奏"
            },
            {
                risk: "忽视社交圈",
                description: "只关注她个人，忽视了她的朋友和社交环境",
                warning_signs: ["朋友对你有负面评价", "她不愿介绍朋友认识"],
                avoidance: "善待她的朋友，参与群体活动，建立良好的社交形象",
                remedy: "主动和她的朋友建立友谊，展现社交能力"
            },
            {
                risk: "过度投资",
                description: "在关系确定前投入过多时间、精力和金钱",
                warning_signs: ["花费超出预算", "忽略其他生活领域", "情绪完全依赖她"],
                avoidance: "保持理性，平衡投入，维持自己的生活重心",
                remedy: "重新评估关系进展，调整投入比例，培养其他兴趣"
            },
            {
                risk: "沟通误解",
                description: "文字交流容易产生歧义，面对面沟通不足",
                warning_signs: ["经常解释误会", "她表现出困惑", "氛围变得尴尬"],
                avoidance: "重要事情当面说，及时澄清误解，增加面对面交流",
                remedy: "主动解释，诚恳道歉，邀请当面深入沟通"
            }
        ],
        emergencyHandling: {
            被拒绝时: "优雅接受，表示理解，保持友谊，为未来留可能性",
            她有男朋友: "立即后退，表示祝福，转为普通朋友，不要破坏别人感情",
            进展停滞: "主动反思，调整策略，可能需要暂时冷却，给彼此空间",
            出现竞争对手: "专注自身优势，不恶意竞争，展现格局和自信"
        },
        successMaintenance: {
            关系确定后: "继续保持吸引力，平衡依恋和独立，持续成长",
            长期发展: "建立共同目标，处理冲突，维持激情，规划未来"
        }
    };
}

// 生成HTML报告
function generateHTMLReport(analysisData) {
    const reportDate = new Date().toLocaleString('zh-CN');
    
    return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>朋友圈深度分析报告 - AI恋爱助手</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .report-container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .report-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-align: center;
            padding: 40px 20px;
        }
        
        .report-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .report-subtitle {
            font-size: 1.2rem;
            opacity: 0.9;
            margin-bottom: 20px;
        }
        
        .report-meta {
            font-size: 0.9rem;
            opacity: 0.8;
        }
        
        .report-content {
            padding: 40px;
        }
        
        .section {
            margin-bottom: 40px;
            border-radius: 15px;
            background: #f8f9fa;
            padding: 30px;
            border-left: 5px solid #667eea;
        }
        
        .section-title {
            font-size: 1.8rem;
            color: #333;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .section-icon {
            font-size: 1.5rem;
        }
        
        .tags {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 15px;
        }
        
        .tag {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .attraction-tag {
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
        }
        
        .profile-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .profile-item {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            border-left: 3px solid #667eea;
        }
        
        .profile-item h4 {
            color: #667eea;
            margin-bottom: 10px;
            font-size: 1rem;
        }
        
        .profile-item p {
            color: #666;
            font-size: 0.9rem;
        }
        
        .success-tag {
            background: linear-gradient(135deg, #28a745, #20c997);
        }
        
        .warning-tag {
            background: linear-gradient(135deg, #ffc107, #fd7e14);
            color: #333;
        }
        
        .info-tag {
            background: linear-gradient(135deg, #17a2b8, #007bff);
        }
        
        .danger-tag {
            background: linear-gradient(135deg, #dc3545, #e83e8c);
        }
        
        .conversation-flow {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .flow-item {
            background: white;
            padding: 15px;
            border-radius: 10px;
            border-left: 3px solid #667eea;
        }
        
        .flow-item h5 {
            color: #667eea;
            margin-bottom: 8px;
            font-size: 1rem;
        }
        
        .flow-item p {
            color: #666;
            font-size: 0.9rem;
            margin: 0;
        }
        
        .message-structure {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .structure-item {
            padding: 10px 0;
            border-bottom: 1px solid #e9ecef;
            font-size: 0.95rem;
            color: #555;
        }
        
        .structure-item:last-child {
            border-bottom: none;
        }
        
        .structure-item strong {
            color: #333;
        }
        
        .emotional-calibration {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .signal-group {
            margin-bottom: 20px;
        }
        
        .signal-group:last-child {
            margin-bottom: 0;
        }
        
        .signal-group h5 {
            margin-bottom: 10px;
            color: #333;
            font-size: 1rem;
        }
        
        .subsection {
            margin-bottom: 25px;
        }
        
        .subsection-title {
            font-size: 1.3rem;
            color: #555;
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        .description {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #666;
            margin-bottom: 15px;
        }
        
        .strategy-phase {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 3px solid #667eea;
        }
        
        .phase-title {
            font-weight: 600;
            font-size: 1.2rem;
            color: #333;
            margin-bottom: 10px;
        }
        
        .phase-duration {
            color: #667eea;
            font-weight: 500;
            margin-bottom: 10px;
        }
        
        .action-list, .goal-list {
            list-style: none;
            padding-left: 0;
        }
        
        .action-list li, .goal-list li {
            padding: 5px 0;
            padding-left: 20px;
            position: relative;
        }
        
        .action-list li:before {
            content: "▶";
            color: #667eea;
            position: absolute;
            left: 0;
        }
        
        .goal-list li:before {
            content: "★";
            color: #ffd700;
            position: absolute;
            left: 0;
        }
        
        .chat-topic {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 3px solid #28a745;
        }
        
        .date-recommendation {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 3px solid #ff6b6b;
        }
        
        .risk-warning {
            background: #fff3cd;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 3px solid #ffc107;
        }
        
        .footer {
            background: #f8f9fa;
            text-align: center;
            padding: 30px;
            color: #666;
            border-top: 1px solid #e9ecef;
        }
        
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .report-container {
                box-shadow: none;
                border-radius: 0;
            }
        }
        
        @media (max-width: 768px) {
            .report-title {
                font-size: 2rem;
            }
            
            .report-content {
                padding: 20px;
            }
            
            .section {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <div class="report-header">
            <h1 class="report-title">💕 朋友圈深度分析报告</h1>
            <p class="report-subtitle">AI恋爱助手 - 专业心理洞察与追求策略</p>
            <p class="report-meta">生成时间: ${reportDate}</p>
        </div>
        
        <div class="report-content">
            <!-- 目标对象画像 -->
            <div class="section">
                <h2 class="section-title">
                    <span class="section-icon">🎯</span>
                    目标对象画像
                </h2>
                
                <div class="profile-grid">
                    <div class="profile-item">
                        <h4>年龄范围</h4>
                        <p>${analysisData.targetProfile.ageRange}</p>
                    </div>
                    <div class="profile-item">
                        <h4>人生阶段</h4>
                        <p>${analysisData.targetProfile.lifeStage}</p>
                    </div>
                    <div class="profile-item">
                        <h4>经济水平</h4>
                        <p>${analysisData.targetProfile.economicLevel}</p>
                    </div>
                    <div class="profile-item">
                        <h4>社交状态</h4>
                        <p>${analysisData.targetProfile.socialStatus}</p>
                    </div>
                </div>
            </div>
            
            <!-- 深度性格分析 -->
            <div class="section">
                <h2 class="section-title">
                    <span class="section-icon">🧠</span>
                    深度性格分析
                </h2>
                
                <div class="subsection">
                    <h3 class="subsection-title">核心特质</h3>
                    <div class="tags">
                        ${analysisData.deepPersonality.coreTraits.map(trait => `<span class="tag">${trait}</span>`).join('')}
                    </div>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">价值观倾向</h3>
                    <div class="tags">
                        ${analysisData.deepPersonality.values.map(value => `<span class="tag">${value}</span>`).join('')}
                    </div>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">生活态度</h3>
                    <p class="description">${analysisData.deepPersonality.lifestyle}</p>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">情绪模式</h3>
                    <p class="description">${analysisData.deepPersonality.emotionalPattern}</p>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">防御机制</h3>
                    <p class="description">${analysisData.deepPersonality.defenseMechanism}</p>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">吸引触发点</h3>
                    <div class="tags">
                        ${analysisData.deepPersonality.attractionTriggers.map(trigger => `<span class="tag attraction-tag">${trigger}</span>`).join('')}
                    </div>
                </div>
            </div>
            
            <!-- 兴趣爱好详解 -->
            <div class="section">
                <h2 class="section-title">
                    <span class="section-icon">⭐</span>
                    兴趣爱好详解
                </h2>
                
                <div class="subsection">
                    <h3 class="subsection-title">主要兴趣</h3>
                    <div class="tags">
                        ${analysisData.detailedInterests.primaryInterests.map(interest => `<span class="tag">${interest}</span>`).join('')}
                    </div>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">生活方式</h3>
                    <div class="tags">
                        ${analysisData.detailedInterests.lifestyle.map(style => `<span class="tag">${style}</span>`).join('')}
                    </div>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">消费习惯</h3>
                    <div class="tags">
                        ${analysisData.detailedInterests.consumption.map(habit => `<span class="tag">${habit}</span>`).join('')}
                    </div>
                </div>
            </div>
            
            <!-- 社交模式分析 -->
            <div class="section">
                <h2 class="section-title">
                    <span class="section-icon">👥</span>
                    社交模式分析
                </h2>
                
                <div class="subsection">
                    <h3 class="subsection-title">社交网络特点</h3>
                    <p class="description">${analysisData.socialPattern.networkStyle}</p>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">发布习惯</h3>
                    <p class="description">${analysisData.socialPattern.postingHabits}</p>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">互动方式</h3>
                    <p class="description">${analysisData.socialPattern.interactionStyle}</p>
                </div>
            </div>
            
            <!-- 恋爱心理分析 -->
            <div class="section">
                <h2 class="section-title">
                    <span class="section-icon">💖</span>
                    恋爱心理分析
                </h2>
                
                <div class="subsection">
                    <h3 class="subsection-title">当前状态</h3>
                    <p class="description">${analysisData.loveAnalysis.currentStatus}</p>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">择偶偏好</h3>
                    <div class="tags">
                        ${analysisData.loveAnalysis.preferences.map(pref => `<span class="tag">${pref}</span>`).join('')}
                    </div>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">恋爱准备度</h3>
                    <p class="description">${analysisData.loveAnalysis.readiness}</p>
                </div>
            </div>
            
            <!-- 追求策略 -->
            <div class="section">
                <h2 class="section-title">
                    <span class="section-icon">🎯</span>
                    分阶段追求策略
                </h2>
                
                ${analysisData.pursuitStrategy.phases.map(phase => `
                    <div class="strategy-phase">
                        <div class="phase-title">${phase.phase}</div>
                        <div class="phase-duration">建议时长: ${phase.duration}</div>
                        
                        <h4>具体行动:</h4>
                        <ul class="action-list">
                            ${phase.actions.map(action => `<li>${action}</li>`).join('')}
                        </ul>
                        
                        <h4>阶段目标:</h4>
                        <ul class="goal-list">
                            ${phase.goals.map(goal => `<li>${goal}</li>`).join('')}
                        </ul>
                    </div>
                `).join('')}
                
                <div class="subsection">
                    <h3 class="subsection-title">整体策略</h3>
                    <p class="description">${analysisData.pursuitStrategy.overallApproach}</p>
                </div>
            </div>
            
            <!-- 沟通指南 -->
            <div class="section">
                <h2 class="section-title">
                    <span class="section-icon">💬</span>
                    沟通技巧指南
                </h2>
                
                <div class="subsection">
                    <h3 class="subsection-title">推荐聊天话题</h3>
                    ${analysisData.communicationGuide.chatTopics.map(topic => `
                        <div class="chat-topic">
                            <h4>${topic.topic}</h4>
                            <p><strong>具体例子:</strong> ${topic.examples.join('、')}</p>
                            <p><strong>沟通技巧:</strong> ${topic.tips.join('、')}</p>
                            <p><strong>最佳时机:</strong> ${topic.timing}</p>
                            <p><strong>进阶技巧:</strong> ${topic.进阶技巧.join('、')}</p>
                        </div>
                    `).join('')}
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">推荐沟通风格</h3>
                    <p class="description">${analysisData.communicationGuide.conversationStyle}</p>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">对话流程控制</h3>
                    <div class="conversation-flow">
                        <div class="flow-item">
                            <h5>开场</h5>
                            <p>${analysisData.communicationGuide.conversationFlow.opening}</p>
                        </div>
                        <div class="flow-item">
                            <h5>维持</h5>
                            <p>${analysisData.communicationGuide.conversationFlow.maintenance}</p>
                        </div>
                        <div class="flow-item">
                            <h5>深入</h5>
                            <p>${analysisData.communicationGuide.conversationFlow.deepening}</p>
                        </div>
                        <div class="flow-item">
                            <h5>收尾</h5>
                            <p>${analysisData.communicationGuide.conversationFlow.closing}</p>
                        </div>
                    </div>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">消息结构指南</h3>
                    <div class="message-structure">
                        <div class="structure-item">
                            <strong>频率控制:</strong> ${analysisData.communicationGuide.messageStructure.frequency}
                        </div>
                        <div class="structure-item">
                            <strong>长度把握:</strong> ${analysisData.communicationGuide.messageStructure.length}
                        </div>
                        <div class="structure-item">
                            <strong>时机选择:</strong> ${analysisData.communicationGuide.messageStructure.timing}
                        </div>
                        <div class="structure-item">
                            <strong>回复节奏:</strong> ${analysisData.communicationGuide.messageStructure.response}
                        </div>
                    </div>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">情感信号识别</h3>
                    <div class="emotional-calibration">
                        <div class="signal-group">
                            <h5>📈 升级信号</h5>
                            <div class="tags">
                                ${analysisData.communicationGuide.emotionalCalibration.升级时机.map(signal => `<span class="tag success-tag">${signal}</span>`).join('')}
                            </div>
                        </div>
                        <div class="signal-group">
                            <h5>📉 降温信号</h5>
                            <div class="tags">
                                ${analysisData.communicationGuide.emotionalCalibration.降温信号.map(signal => `<span class="tag warning-tag">${signal}</span>`).join('')}
                            </div>
                        </div>
                        <div class="signal-group">
                            <h5>🔍 关键指标</h5>
                            <div class="tags">
                                ${analysisData.communicationGuide.emotionalCalibration.读懂信号.map(signal => `<span class="tag info-tag">${signal}</span>`).join('')}
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="subsection">
                    <h3 class="subsection-title">聊天禁忌</h3>
                    <div class="tags">
                        ${analysisData.communicationGuide.taboos.map(taboo => `<span class="tag danger-tag">${taboo}</span>`).join('')}
                    </div>
                </div>
            </div>
            
            <!-- 约会建议 -->
            <div class="section">
                <h2 class="section-title">
                    <span class="section-icon">🌹</span>
                    约会规划建议
                </h2>
                
                ${analysisData.dateRecommendations.map(date => `
                    <div class="date-recommendation">
                        <h4>${date.type}</h4>
                        <p><strong>推荐地点:</strong> ${date.location}</p>
                        <p><strong>最佳时机:</strong> ${date.timing}</p>
                        <p><strong>准备事项:</strong> ${date.preparation.join('、')}</p>
                        <p><strong>推荐理由:</strong> ${date.reasons}</p>
                    </div>
                `).join('')}
            </div>
            
            <!-- 风险提示 -->
            <div class="section">
                <h2 class="section-title">
                    <span class="section-icon">⚠️</span>
                    风险提示
                </h2>
                
                ${analysisData.riskWarnings.map(warning => `
                    <div class="risk-warning">
                        <h4>${warning.risk}</h4>
                        <p><strong>风险说明:</strong> ${warning.description}</p>
                        <p><strong>规避方法:</strong> ${warning.avoidance}</p>
                    </div>
                `).join('')}
            </div>
        </div>
        
        <div class="footer">
            <p>💕 朋友圈五宫格 - AI恋爱助手</p>
            <p>用AI读懂Ta的心，让爱情更有迹可循</p>
            <p>报告生成时间: ${reportDate}</p>
        </div>
    </div>
</body>
</html>`;
}

// API路由：分析朋友圈截图
app.post('/api/analyze', async (req, res) => {
    try {
        const { images } = req.body;
        
        if (!images || !Array.isArray(images) || images.length === 0) {
            return res.status(400).json({
                error: '请提供至少一张图片'
            });
        }
        
        console.log(`收到分析请求，图片数量: ${images.length}`);
        
        // 准备图片数据
        const imageDataUrls = images.map(img => img.dataUrl);
        
        // 构建分析提示词
        const analysisPrompt = `
请分析这些朋友圈截图，从以下维度进行分析：

1. 性格特征（外向/内向、感性/理性等）
2. 兴趣爱好（运动、艺术、美食、旅行等）  
3. 生活状态（工作、经济水平、社交圈等）
4. 沟通风格（幽默、严肃、文艺等）

请根据图片内容（包括文字、图片内容、发布时间等），分析这个人的特征并提供追求建议。

请严格按照JSON格式返回结果，不要包含任何其他文字。
        `;
        
        console.log('正在调用豆包API分析...');
        
        // 调用豆包API，直接传入图片
        const analysisResult = await callDoubaoAPI(imageDataUrls, analysisPrompt);
        
        console.log('分析完成:', analysisResult);
        
        res.json({
            success: true,
            data: analysisResult
        });
        
    } catch (error) {
        console.error('分析过程出错:', error);
        
        // 返回备用结果
        const fallbackResult = getMockAnalysisResult();
        
        res.json({
            success: true,
            data: fallbackResult,
            note: '使用模拟数据（API调用失败）'
        });
    }
});

// API路由：生成详细分析报告
app.post('/api/detailed-analyze', async (req, res) => {
    try {
        const { images } = req.body;
        
        if (!images || !Array.isArray(images) || images.length === 0) {
            return res.status(400).json({
                error: '请提供至少一张图片'
            });
        }
        
        console.log(`收到详细分析请求，图片数量: ${images.length}`);
        
        // 准备图片数据
        const imageDataUrls = images.map(img => img.dataUrl);
        
        // 构建详细分析提示词
        const detailedPrompt = `
请对这些朋友圈截图进行深度分析，提供专业的心理洞察和追求建议。

请仔细观察图片中的每个细节：
- 发布的文字内容和语言风格
- 图片内容（场景、物品、人物等）
- 发布时间和频率模式
- 点赞和评论的互动情况
- 整体的生活状态展现

基于这些信息，请进行深度分析并严格按照JSON格式返回结果。
        `;
        
        console.log('正在调用豆包API进行详细分析...');
        console.log('图片数据示例:', imageDataUrls[0] ? imageDataUrls[0].substring(0, 50) + '...' : 'none');
        
        // 调用豆包API，使用详细分析prompt
        const detailedResult = await callDoubaoAPI(imageDataUrls, detailedPrompt, true);
        
        console.log('详细分析完成:', detailedResult);
        
        // 生成HTML报告 - 如果API返回的不是详细格式，使用模拟数据
        let reportData = detailedResult;
        if (!detailedResult.deepPersonality) {
            console.log('AI返回格式不匹配，使用模拟详细数据');
            reportData = getDetailedMockAnalysisResult();
        }
        
        const htmlReport = generateHTMLReport(reportData);
        
        res.json({
            success: true,
            data: detailedResult,
            htmlReport: htmlReport
        });
        
    } catch (error) {
        console.error('详细分析过程出错:', error);
        
        // 返回备用结果
        const fallbackResult = getDetailedMockAnalysisResult();
        const htmlReport = generateHTMLReport(fallbackResult);
        
        res.json({
            success: true,
            data: fallbackResult,
            htmlReport: htmlReport,
            note: '使用模拟数据（API调用失败）'
        });
    }
});

// 健康检查接口
app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: '2.0.0'
    });
});

// 获取配置信息接口
app.get('/api/config', (req, res) => {
    res.json({
        maxImages: 20,
        minImages: 5,
        maxFileSize: 10 * 1024 * 1024,
        supportedFormats: ['image/jpeg', 'image/png', 'image/webp']
    });
});

// 错误处理中间件
app.use((error, req, res, next) => {
    console.error('服务器错误:', error);
    res.status(500).json({
        error: '服务器内部错误',
        message: error.message
    });
});

// 404处理
app.use((req, res) => {
    res.status(404).json({
        error: '接口不存在'
    });
});

// 启动服务器
app.listen(PORT, () => {
    console.log(`🚀 朋友圈五宫格服务器启动成功！`);
    console.log(`📱 访问地址: http://localhost:${PORT}`);
    console.log(`🔧 API地址: http://localhost:${PORT}/api`);
    console.log(`💡 豆包模型: ${DOUBAO_CONFIG.model}`);
    
    if (!process.env.DOUBAO_API_KEY) {
        console.warn('⚠️  警告: 未设置DOUBAO_API_KEY环境变量，将使用模拟数据');
        console.warn('   请设置环境变量: export DOUBAO_API_KEY=your-api-key');
    }
});

// 优雅关闭
process.on('SIGTERM', () => {
    console.log('收到终止信号，正在关闭服务器...');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('收到中断信号，正在关闭服务器...');
    process.exit(0);
});

module.exports = app; 