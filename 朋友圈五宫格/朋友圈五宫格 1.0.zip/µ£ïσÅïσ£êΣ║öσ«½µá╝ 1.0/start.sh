#!/bin/bash

echo "🚀 启动朋友圈五宫格 - AI恋爱助手"
echo "=================================="

# 检查Node.js环境
if ! command -v node &> /dev/null; then
    echo "❌ 错误: 未找到Node.js，请先安装Node.js (版本 >= 16.0.0)"
    exit 1
fi

# 检查package.json
if [ ! -f "package.json" ]; then
    echo "❌ 错误: 未找到package.json文件"
    exit 1
fi

# 安装依赖
if [ ! -d "node_modules" ]; then
    echo "📦 安装项目依赖..."
    npm install
    if [ $? -ne 0 ]; then
        echo "❌ 依赖安装失败"
        exit 1
    fi
fi

# 检查环境变量
if [ -z "$DOUBAO_API_KEY" ]; then
    echo "⚠️  警告: 未设置DOUBAO_API_KEY环境变量"
    echo "   将使用模拟数据进行演示"
    echo "   要使用真实AI分析，请设置: export DOUBAO_API_KEY=your-api-key"
    echo ""
fi

# 启动服务器
echo "🎯 启动服务器..."
npm start 