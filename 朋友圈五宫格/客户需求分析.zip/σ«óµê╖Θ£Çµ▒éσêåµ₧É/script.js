// 豆包API配置
const DOUBAO_CONFIG = {
    apiKey: '8ceb1e51-6022-479f-97c4-f78a791ddbd6',
    apiUrl: 'https://ark.cn-beijing.volces.com/api/v3/chat/completions',
    model: 'doubao-seed-1-6-thinking-250615'
};

// 全局变量
let uploadedImages = [];
let analysisResult = null;

// DOM元素
const elements = {
    uploadZone: document.getElementById('upload-zone'),
    fileInput: document.getElementById('file-input'),
    uploadBtn: document.getElementById('upload-btn'),
    addMoreBtn: document.getElementById('add-more-btn'),
    analyzeBtn: document.getElementById('analyze-btn'),
    restartBtn: document.getElementById('restart-btn'),
    exportBtn: document.getElementById('export-btn'),
    previewContainer: document.getElementById('preview-container'),
    previewGrid: document.getElementById('preview-grid'),
    imageCount: document.getElementById('image-count'),
    uploadSection: document.getElementById('upload-section'),
    loadingSection: document.getElementById('loading-section'),
    resultSection: document.getElementById('result-section'),
    progressFill: document.getElementById('progress-fill'),
    progressText: document.getElementById('progress-text'),
    insightContent: document.getElementById('insight-content'),
    toast: document.getElementById('toast'),
    toastMessage: document.getElementById('toast-message')
};

// 初始化事件监听器
function initEventListeners() {
    // 上传按钮点击
    elements.uploadBtn.addEventListener('click', () => {
        elements.fileInput.click();
    });

    // 继续添加按钮点击
    elements.addMoreBtn.addEventListener('click', () => {
        elements.fileInput.click();
    });

    // 文件选择
    elements.fileInput.addEventListener('change', handleFileSelect);

    // 拖拽上传
    elements.uploadZone.addEventListener('dragover', handleDragOver);
    elements.uploadZone.addEventListener('dragleave', handleDragLeave);
    elements.uploadZone.addEventListener('drop', handleDrop);

    // 分析按钮
    elements.analyzeBtn.addEventListener('click', startAnalysis);

    // 重新分析按钮
    elements.restartBtn.addEventListener('click', restartAnalysis);

    // 导出按钮
    elements.exportBtn.addEventListener('click', exportReport);

    // 标签页切换
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });
}

// 处理文件选择
function handleFileSelect(event) {
    const files = Array.from(event.target.files);
    processFiles(files);
    event.target.value = ''; // 清空input，允许重复选择相同文件
}

// 处理拖拽
function handleDragOver(event) {
    event.preventDefault();
    elements.uploadZone.classList.add('dragover');
}

function handleDragLeave(event) {
    event.preventDefault();
    elements.uploadZone.classList.remove('dragover');
}

function handleDrop(event) {
    event.preventDefault();
    elements.uploadZone.classList.remove('dragover');
    const files = Array.from(event.dataTransfer.files);
    processFiles(files);
}

// 处理文件
function processFiles(files) {
    const validFiles = files.filter(file => {
        if (!file.type.startsWith('image/')) {
            showToast('只能上传图片文件');
            return false;
        }
        if (file.size > 10 * 1024 * 1024) {
            showToast('图片大小不能超过10MB');
            return false;
        }
        return true;
    });

    if (uploadedImages.length + validFiles.length > 20) {
        showToast('最多只能上传20张图片');
        return;
    }

    validFiles.forEach(addImage);
    updateUI();
}

// 添加图片
function addImage(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
        const imageData = {
            id: Date.now() + Math.random(),
            file: file,
            url: e.target.result,
            name: file.name
        };
        uploadedImages.push(imageData);
        renderPreview();
        updateUI();
    };
    reader.readAsDataURL(file);
}

// 渲染预览
function renderPreview() {
    elements.previewGrid.innerHTML = '';
    
    uploadedImages.forEach(image => {
        const previewItem = document.createElement('div');
        previewItem.className = 'preview-item';
        previewItem.innerHTML = `
            <img src="${image.url}" alt="${image.name}">
            <button class="remove-btn" onclick="removeImage('${image.id}')">
                <i class="fas fa-times"></i>
            </button>
        `;
        elements.previewGrid.appendChild(previewItem);
    });
}

// 移除图片
function removeImage(imageId) {
    uploadedImages = uploadedImages.filter(img => img.id !== imageId);
    renderPreview();
    updateUI();
}

// 更新UI状态
function updateUI() {
    const count = uploadedImages.length;
    elements.imageCount.textContent = count;
    
    // 显示/隐藏预览容器
    if (count > 0) {
        elements.previewContainer.style.display = 'block';
        elements.analyzeBtn.disabled = count < 5;
    } else {
        elements.previewContainer.style.display = 'none';
    }
}

// 开始分析
async function startAnalysis() {
    if (uploadedImages.length < 5) {
        showToast('请至少上传5张图片');
        return;
    }

    // 切换到加载界面
    elements.uploadSection.style.display = 'none';
    elements.loadingSection.style.display = 'block';
    elements.resultSection.style.display = 'none';

    try {
        // 模拟进度更新
        updateProgress(0);
        
        // 转换图片为base64
        updateProgress(10);
        const imageUrls = await convertImagesToBase64();
        
        updateProgress(30);
        
        // 调用豆包API
        const result = await callDoubaoAPI(imageUrls);
        
        updateProgress(80);
        
        // 处理结果
        analysisResult = parseAnalysisResult(result);
        
        updateProgress(100);
        
        // 延迟显示结果
        setTimeout(() => {
            showResults();
        }, 1000);
        
    } catch (error) {
        console.error('分析失败:', error);
        showToast('分析失败，请稍后重试');
        elements.loadingSection.style.display = 'none';
        elements.uploadSection.style.display = 'block';
    }
}

// 更新进度
function updateProgress(percentage) {
    elements.progressFill.style.width = percentage + '%';
    elements.progressText.textContent = percentage + '%';
}

// 转换图片为base64
function convertImagesToBase64() {
    return Promise.all(uploadedImages.map(image => {
        return new Promise((resolve) => {
            resolve(image.url);
        });
    }));
}

// 调用豆包API
async function callDoubaoAPI(imageUrls) {
    const messages = [{
        role: 'user',
        content: [
            {
                type: 'text',
                text: `作为一名拥有15年销售经验的资深销售总监，我需要你深度分析这些朋友圈截图，挖掘客户的深层心理特征和消费决策驱动因素。请运用消费者行为学、心理学和销售心理学理论，进行专业级的客户画像分析。

# 分析框架要求：

## 1. 深度心理画像分析
- **决策动机**：分析客户的核心驱动力（成就感、安全感、归属感、自我实现等）
- **消费心理**：理性vs感性、保守vs冒险、品质vs价格敏感度
- **社会认知**：客户希望在他人眼中呈现的形象和地位
- **生活压力与痛点**：识别客户可能面临的挑战和需求缺口

## 2. 消费能力与行为深度解析
- **经济实力评估**：从展示内容推断收入水平、资产状况、消费预算
- **消费决策模式**：冲动型/理性型、品牌忠诚度、价格敏感性
- **购买周期习惯**：消费频次、季节性偏好、购买时机选择
- **影响因素权重**：家庭意见、朋友推荐、专家建议、广告营销的影响力

## 3. 社交影响力与圈层分析
- **社交地位与话语权**：在朋友圈的影响力和被关注度
- **圈层特征**：职业圈、兴趣圈、地域圈的交叉分析
- **社交需求**：展示型、互动型、学习型、娱乐型需求
- **意见领袖潜质**：是否具备带动他人消费的能力

## 4. 风险评估与机会识别
- **客户价值评估**：短期价值、长期价值、转介绍潜力
- **成交概率分析**：基于性格特征预估成交难度和周期
- **潜在异议点**：可能的顾虑和抗拒心理
- **最佳切入时机**：基于生活状态判断接触的最佳时间点

## 5. 精准销售策略制定
- **沟通风格匹配**：正式/轻松、直接/委婉、情感/理性导向
- **产品推荐逻辑**：基于需求层次和心理驱动的产品匹配
- **价格策略建议**：折扣敏感度、支付方式偏好、价格锚点设置
- **关系建立路径**：从陌生到信任的具体步骤和话术建议
- **异议处理预案**：针对性格特征的异议化解策略

请用以下JSON格式返回专业分析结果：
{
  "summary": "客户整体画像总结(150-200字，突出关键特征和销售机会点)",
  "psychologyProfile": {
    "coreMotivation": "核心驱动力分析",
    "decisionStyle": "决策风格(理性/感性程度、风险偏好等)",
    "socialImage": "期望社会形象",
    "painPoints": ["痛点1", "痛点2", "痛点3"]
  },
  "consumptionAnalysis": {
    "economicLevel": "经济实力评估(具体收入区间推测)",
    "spendingHabits": ["消费习惯1", "消费习惯2", "消费习惯3"],
    "decisionFactors": ["影响购买的关键因素1", "因素2", "因素3"],
    "priceStrategy": "价格敏感度和支付偏好分析"
  },
  "socialInfluence": {
    "circleLevel": "社交圈层和地位分析", 
    "influencePower": "影响力评估",
    "networkValue": "人脉价值和转介绍潜力",
    "socialNeeds": ["社交需求1", "需求2"]
  },
  "riskOpportunity": {
    "customerValue": "客户价值评估(1-10分及理由)",
    "closingProbability": "成交概率预估和周期",
    "potentialObjections": ["可能异议1", "异议2"],
    "bestTiming": "最佳接触时机建议"
  },
  "salesStrategy": {
    "communicationStyle": "推荐沟通风格和语调",
    "approachMethod": "初次接触的最佳方式",
    "productRecommendation": ["推荐产品类型1", "类型2", "类型3"],
    "pricingTactics": "定价和优惠策略",
    "relationshipBuilding": ["关系建立步骤1", "步骤2", "步骤3"],
    "objectionHandling": ["异议处理策略1", "策略2"],
    "followUpPlan": "后续跟进计划和频率"
  },
  "actionPlan": {
    "immediateActions": ["立即可执行的行动1", "行动2"],
    "shortTermGoals": ["1个月内目标1", "目标2"],
    "longTermStrategy": "长期客户关系维护策略"
  }
}`
            },
            ...imageUrls.map(url => ({
                type: 'image_url',
                image_url: { url }
            }))
        ]
    }];

    const response = await fetch(DOUBAO_CONFIG.apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${DOUBAO_CONFIG.apiKey}`
        },
        body: JSON.stringify({
            model: DOUBAO_CONFIG.model,
            messages: messages,
            max_tokens: 2000,
            temperature: 0.7
        })
    });

    if (!response.ok) {
        throw new Error(`API调用失败: ${response.status}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
}

// 解析分析结果
function parseAnalysisResult(content) {
    try {
        // 尝试提取JSON部分
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
            return JSON.parse(jsonMatch[0]);
        }
        
        // 如果没有找到JSON，返回默认结构
        return {
            summary: content.substring(0, 200) + '...',
            psychologyProfile: {
                coreMotivation: '无法分析',
                decisionStyle: '无法评估',
                socialImage: '无法识别',
                painPoints: ['无法识别']
            },
            consumptionAnalysis: {
                economicLevel: '无法评估',
                spendingHabits: ['无法识别'],
                decisionFactors: ['无法识别'],
                priceStrategy: '无法分析'
            },
            socialInfluence: {
                circleLevel: '无法分析',
                influencePower: '无法评估',
                networkValue: '无法识别',
                socialNeeds: ['无法识别']
            },
            riskOpportunity: {
                customerValue: '无法评估',
                closingProbability: '无法预估',
                potentialObjections: ['无法识别'],
                bestTiming: '建议进一步观察'
            },
            salesStrategy: {
                communicationStyle: '建议保持友好',
                approachMethod: '建议谨慎接触',
                productRecommendation: ['根据后续了解推荐'],
                pricingTactics: '建议灵活定价',
                relationshipBuilding: ['建立基础信任'],
                objectionHandling: ['耐心解答疑问'],
                followUpPlan: '定期跟进'
            },
            actionPlan: {
                immediateActions: ['收集更多信息'],
                shortTermGoals: ['建立初步联系'],
                longTermStrategy: '长期关系维护'
            }
        };
    } catch (error) {
        console.error('解析结果失败:', error);
        return null;
    }
}

// 显示结果
function showResults() {
    elements.loadingSection.style.display = 'none';
    elements.resultSection.style.display = 'block';
    
    if (!analysisResult) {
        showToast('分析结果解析失败');
        return;
    }
    
    renderResults();
}

// 渲染结果
function renderResults() {
    // 渲染核心洞察
    elements.insightContent.innerHTML = `
        <p>${analysisResult.summary}</p>
    `;
    
    // 渲染各个标签页内容
    renderPsychologyTab();
    renderConsumptionTab();
    renderSocialTab();
    renderRiskOpportunityTab();
    renderSalesTab();
}

// 渲染心理画像标签页
function renderPsychologyTab() {
    const pane = document.getElementById('interests-pane');
    pane.innerHTML = `
        <div class="analysis-card">
            <h5><i class="fas fa-brain"></i> 核心驱动力</h5>
            <p>${analysisResult.psychologyProfile.coreMotivation}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-chart-line"></i> 决策风格</h5>
            <p>${analysisResult.psychologyProfile.decisionStyle}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-mask"></i> 期望社会形象</h5>
            <p>${analysisResult.psychologyProfile.socialImage}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-exclamation-triangle"></i> 关键痛点</h5>
            <div class="tag-list">
                ${analysisResult.psychologyProfile.painPoints.map(point => 
                    `<span class="tag"><i class="fas fa-tag"></i> ${point}</span>`
                ).join('')}
            </div>
        </div>
    `;
}

// 渲染消费分析标签页
function renderConsumptionTab() {
    const pane = document.getElementById('consumption-pane');
    pane.innerHTML = `
        <div class="analysis-card">
            <h5><i class="fas fa-credit-card"></i> 经济实力评估</h5>
            <p>${analysisResult.consumptionAnalysis.economicLevel}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-shopping-bag"></i> 消费习惯</h5>
            <div class="tag-list">
                ${analysisResult.consumptionAnalysis.spendingHabits.map(habit => 
                    `<span class="tag"><i class="fas fa-tag"></i> ${habit}</span>`
                ).join('')}
            </div>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-bullseye"></i> 决策影响因素</h5>
            <div class="tag-list">
                ${analysisResult.consumptionAnalysis.decisionFactors.map(factor => 
                    `<span class="tag"><i class="fas fa-tag"></i> ${factor}</span>`
                ).join('')}
            </div>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-dollar-sign"></i> 价格策略分析</h5>
            <p>${analysisResult.consumptionAnalysis.priceStrategy}</p>
        </div>
    `;
}

// 渲染风险机会标签页
function renderRiskOpportunityTab() {
    const pane = document.getElementById('lifestyle-pane');
    pane.innerHTML = `
        <div class="analysis-card">
            <h5><i class="fas fa-star"></i> 客户价值评估</h5>
            <p>${analysisResult.riskOpportunity.customerValue}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-percentage"></i> 成交概率分析</h5>
            <p>${analysisResult.riskOpportunity.closingProbability}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-shield-alt"></i> 潜在异议点</h5>
            <div class="tag-list">
                ${analysisResult.riskOpportunity.potentialObjections.map(objection => 
                    `<span class="tag"><i class="fas fa-tag"></i> ${objection}</span>`
                ).join('')}
            </div>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-clock"></i> 最佳时机建议</h5>
            <p>${analysisResult.riskOpportunity.bestTiming}</p>
        </div>
    `;
}

// 渲染社交影响力标签页
function renderSocialTab() {
    const pane = document.getElementById('social-pane');
    pane.innerHTML = `
        <div class="analysis-card">
            <h5><i class="fas fa-users"></i> 社交圈层分析</h5>
            <p>${analysisResult.socialInfluence.circleLevel}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-broadcast-tower"></i> 影响力评估</h5>
            <p>${analysisResult.socialInfluence.influencePower}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-network-wired"></i> 人脉价值</h5>
            <p>${analysisResult.socialInfluence.networkValue}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-comments"></i> 社交需求</h5>
            <div class="tag-list">
                ${analysisResult.socialInfluence.socialNeeds.map(need => 
                    `<span class="tag"><i class="fas fa-tag"></i> ${need}</span>`
                ).join('')}
            </div>
        </div>
    `;
}

// 渲染销售策略标签页
function renderSalesTab() {
    const pane = document.getElementById('sales-pane');
    pane.innerHTML = `
        <div class="analysis-card">
            <h5><i class="fas fa-microphone"></i> 沟通风格建议</h5>
            <p>${analysisResult.salesStrategy.communicationStyle}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-handshake"></i> 接触方式</h5>
            <p>${analysisResult.salesStrategy.approachMethod}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-box"></i> 产品推荐</h5>
            <div class="tag-list">
                ${analysisResult.salesStrategy.productRecommendation.map(product => 
                    `<span class="tag"><i class="fas fa-tag"></i> ${product}</span>`
                ).join('')}
            </div>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-dollar-sign"></i> 定价策略</h5>
            <p>${analysisResult.salesStrategy.pricingTactics}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-heart"></i> 关系建立步骤</h5>
            <div class="tag-list">
                ${analysisResult.salesStrategy.relationshipBuilding.map(step => 
                    `<span class="tag"><i class="fas fa-tag"></i> ${step}</span>`
                ).join('')}
            </div>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-shield-alt"></i> 异议处理</h5>
            <div class="tag-list">
                ${analysisResult.salesStrategy.objectionHandling.map(strategy => 
                    `<span class="tag"><i class="fas fa-tag"></i> ${strategy}</span>`
                ).join('')}
            </div>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-calendar-alt"></i> 跟进计划</h5>
            <p>${analysisResult.salesStrategy.followUpPlan}</p>
        </div>
        <div class="analysis-card">
            <h5><i class="fas fa-rocket"></i> 行动计划</h5>
            <h6>立即行动:</h6>
            <div class="tag-list">
                ${analysisResult.actionPlan.immediateActions.map(action => 
                    `<span class="tag"><i class="fas fa-play"></i> ${action}</span>`
                ).join('')}
            </div>
            <h6>短期目标:</h6>
            <div class="tag-list">
                ${analysisResult.actionPlan.shortTermGoals.map(goal => 
                    `<span class="tag"><i class="fas fa-target"></i> ${goal}</span>`
                ).join('')}
            </div>
            <h6>长期策略:</h6>
            <p>${analysisResult.actionPlan.longTermStrategy}</p>
        </div>
    `;
}

// 切换标签页
function switchTab(tabName) {
    // 更新标签按钮状态
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    // 更新标签页内容
    document.querySelectorAll('.tab-pane').forEach(pane => {
        pane.classList.remove('active');
    });
    document.getElementById(`${tabName}-pane`).classList.add('active');
}

// 重新分析
function restartAnalysis() {
    uploadedImages = [];
    analysisResult = null;
    
    elements.uploadSection.style.display = 'block';
    elements.loadingSection.style.display = 'none';
    elements.resultSection.style.display = 'none';
    
    renderPreview();
    updateUI();
}

// 导出报告
function exportReport() {
    if (!analysisResult) {
        showToast('没有可导出的报告');
        return;
    }
    
    // 生成报告内容
    const reportContent = generateReportContent();
    
    // 创建下载链接
    const blob = new Blob([reportContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `客户画像分析报告_${new Date().toLocaleDateString()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showToast('报告导出成功', 'success');
}

// 生成报告内容
function generateReportContent() {
    return `资深销售总监级客户画像分析报告
生成时间：${new Date().toLocaleString()}

===== 核心洞察 =====
${analysisResult.summary}

===== 深度心理画像分析 =====
核心驱动力：${analysisResult.psychologyProfile.coreMotivation}
决策风格：${analysisResult.psychologyProfile.decisionStyle}
期望社会形象：${analysisResult.psychologyProfile.socialImage}
关键痛点：${analysisResult.psychologyProfile.painPoints.join('、')}

===== 消费能力与行为分析 =====
经济实力：${analysisResult.consumptionAnalysis.economicLevel}
消费习惯：${analysisResult.consumptionAnalysis.spendingHabits.join('、')}
决策影响因素：${analysisResult.consumptionAnalysis.decisionFactors.join('、')}
价格策略：${analysisResult.consumptionAnalysis.priceStrategy}

===== 社交影响力分析 =====
社交圈层：${analysisResult.socialInfluence.circleLevel}
影响力评估：${analysisResult.socialInfluence.influencePower}
人脉价值：${analysisResult.socialInfluence.networkValue}
社交需求：${analysisResult.socialInfluence.socialNeeds.join('、')}

===== 风险评估与机会识别 =====
客户价值：${analysisResult.riskOpportunity.customerValue}
成交概率：${analysisResult.riskOpportunity.closingProbability}
潜在异议：${analysisResult.riskOpportunity.potentialObjections.join('、')}
最佳时机：${analysisResult.riskOpportunity.bestTiming}

===== 精准销售策略 =====
沟通风格：${analysisResult.salesStrategy.communicationStyle}
接触方式：${analysisResult.salesStrategy.approachMethod}
产品推荐：${analysisResult.salesStrategy.productRecommendation.join('、')}
定价策略：${analysisResult.salesStrategy.pricingTactics}
关系建立：${analysisResult.salesStrategy.relationshipBuilding.join(' → ')}
异议处理：${analysisResult.salesStrategy.objectionHandling.join('、')}
跟进计划：${analysisResult.salesStrategy.followUpPlan}

===== 行动计划 =====
立即行动：${analysisResult.actionPlan.immediateActions.join('、')}
短期目标：${analysisResult.actionPlan.shortTermGoals.join('、')}
长期策略：${analysisResult.actionPlan.longTermStrategy}

===== 报告结束 =====

注：本报告基于AI深度分析生成，建议结合实际情况灵活运用。
`;
}

// 显示提示消息
function showToast(message, type = 'error') {
    elements.toastMessage.textContent = message;
    elements.toast.className = `toast ${type}`;
    elements.toast.classList.add('show');
    
    setTimeout(() => {
        elements.toast.classList.remove('show');
    }, 3000);
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    initEventListeners();
    updateUI();
}); 